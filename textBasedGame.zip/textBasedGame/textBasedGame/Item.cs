﻿using System;
using System.Collections.Generic;
using System.Text;

namespace textBasedGame
{
    class Item
    {

    }
}
